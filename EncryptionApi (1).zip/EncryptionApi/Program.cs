using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public class EncryptionService
{
    private readonly string key = "your-secret-key-here"; 

    public string Encrypt(string plainText)
    {
        using Aes aes = Aes.Create();
        aes.Key = Encoding.UTF8.GetBytes(key.PadRight(32)); 
        aes.GenerateIV();
        using MemoryStream ms = new();
        using CryptoStream cs = new(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
        using StreamWriter sw = new(cs);
        sw.Write(plainText);
        return Convert.ToBase64String(aes.IV) + ":" + Convert.ToBase64String(ms.ToArray());
    }

    public string Decrypt(string cipherText)
    {
        string[] parts = cipherText.Split(':');
        using Aes aes = Aes.Create();
        aes.Key = Encoding.UTF8.GetBytes(key.PadRight(32));
        aes.IV = Convert.FromBase64String(parts[0]);
        using MemoryStream ms = new(Convert.FromBase64String(parts[1]));
        using CryptoStream cs = new(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
        using StreamReader sr = new(cs);
        return sr.ReadToEnd();
    }
}
